const pages = [...document.querySelectorAll(".page")];
const dots = [...document.querySelectorAll(".dot")];
const progress = document.getElementById("progress");

function goToPage(index) {
  pages[index]?.scrollIntoView({ behavior: "smooth" });
}

dots.forEach((dot) => {
  dot.addEventListener("click", () => {
    goToPage(Number(dot.dataset.slide));
  });
});

document.querySelectorAll("[data-next]").forEach((button) => {
  button.addEventListener("click", () => goToPage(1));
});

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;

      const index = pages.indexOf(entry.target);
      dots.forEach((dot, i) => dot.classList.toggle("active", i === index));

      const percent = ((index + 1) / pages.length) * 100;
      progress.style.width = `${percent}%`;
    });
  },
  { threshold: 0.55 }
);

pages.forEach((page) => observer.observe(page));

document.addEventListener("keydown", (event) => {
  const current = dots.findIndex((dot) => dot.classList.contains("active"));

  if (event.key === "ArrowDown" || event.key === "PageDown") {
    event.preventDefault();
    goToPage(Math.min(current + 1, pages.length - 1));
  }

  if (event.key === "ArrowUp" || event.key === "PageUp") {
    event.preventDefault();
    goToPage(Math.max(current - 1, 0));
  }
});
