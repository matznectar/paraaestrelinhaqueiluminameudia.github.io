# Para você — site romântico

## Estrutura

- `index.html` — todas as páginas/textos
- `style.css` — visual, fontes, cores e responsividade
- `script.js` — navegação, bolinhas laterais e barra de progresso
- `images/` — coloque aqui suas fotos JPG

## Fotos

Renomeie suas fotos exatamente assim:

01-capa.jpg
03-dor.jpg
05-voce-me-pediu.jpg
08-outras-mulheres.jpg
09-confianca.jpg
12-escolho-construir.jpg
13-final.jpg

As páginas que não possuem foto continuam funcionando normalmente.

## GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os arquivos mantendo as pastas.
3. Vá em Settings > Pages.
4. Em Source, selecione `Deploy from a branch`.
5. Branch: `main`.
6. Folder: `/ (root)`.
7. Salve.
8. Aguarde a publicação e abra o endereço mostrado pelo GitHub.

O site é totalmente estático: HTML + CSS + JavaScript + JPGs.
